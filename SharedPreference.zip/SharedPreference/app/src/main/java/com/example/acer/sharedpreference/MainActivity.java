package com.example.acer.sharedpreference;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.hotspot2.pps.HomeSp;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name,password;
    String name1,pass1;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void login(View view) {
        SharedPreferences sp=getSharedPreferences("MyPreference",MODE_PRIVATE);
        name1=name.getText().toString();
        pass1=password.getText().toString();
        String name2=sp.getString("user_name",null);
        String pass2=sp.getString("password",null);


        if((name1.equalsIgnoreCase(name2))&&(pass1.equalsIgnoreCase(pass2)))
        {
            Intent intent=new Intent(this, HomeActivity.class);
            startActivity(intent);
            Toast.makeText(this, "login successful", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "login unsuccessful", Toast.LENGTH_SHORT).show();
        }

    }

    public void register(View view) {
        Intent intent = new Intent(this,Main2Activity.class);
        startActivity(intent);
    }
}
