package com.example.acer.sharedpreference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    EditText name,pass,branch,rollnum;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name=findViewById(R.id.name);
        pass=findViewById(R.id.password);
        branch=findViewById(R.id.branch);
        rollnum=findViewById(R.id.rollnum);
        sharedPreferences=getSharedPreferences("MyPreference",MODE_PRIVATE);
        editor=sharedPreferences.edit();
    }

    public void registration(View view) {
        SharedPreferences sp=getSharedPreferences("MyPreference",MODE_PRIVATE);
        SharedPreferences.Editor editor=sp.edit();
        editor.putString("user_name",name.getText().toString());
        editor.putString("password",pass.getText().toString());
        editor.putString("branch",branch.getText().toString());
        editor.putString("rollnum",rollnum.getText().toString());
        editor.apply();
        Toast.makeText(this, "registration", Toast.LENGTH_SHORT).show();
        finish();

    }
}
